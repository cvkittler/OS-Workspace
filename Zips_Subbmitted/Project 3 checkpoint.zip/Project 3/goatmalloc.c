#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include "goatmalloc.h"

void *_arena_start;
int statusno = ERR_UNINITIALIZED;
node_t *header;

extern int init(size_t size){
    //check to see if positive size
    if((int)size < 0){
        return ERR_BAD_ARGUMENTS;
    }
    printf("Initializing arena:\n");
    printf("...requested size %ld bytes\n",size);
    int pageSize = getpagesize();
    printf("...pagesize is %d bytes\n",pageSize);

    //adjust the size to fit the data
    int numPages;
    if((int)size % pageSize != 0){
        numPages = ((int)size / pageSize) + 1;
    }else{
        numPages = ((int)size / pageSize);
    }
    int adjSize = pageSize * numPages;
    printf("...adjusted size is %d bytes\n", adjSize);

    //get the arena
    printf("...mapping arena with mmap()\n");
    int fd=open("/dev/zero",O_RDWR);
    _arena_start = mmap(NULL, adjSize , PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    //check to see if the arena was gotten
    if(_arena_start == MAP_FAILED){
        return ERR_SYSCALL_FAILED;
    }
    printf("...arena starts at %p\n", _arena_start);
    printf("...arena ends at %p\n", _arena_start + adjSize);

    //initialize the header
    printf("...initializing header for initial free chunk\n");
    printf("...header size is %ld\n",sizeof(node_t));
    node_t start;
    start.size = (int)size;
    start.is_free = 1;
    header = &start;

    return adjSize;
}

extern int destroy(){
    if(header == NULL){//no data
        return ERR_UNINITIALIZED;
    }else{//there is data
        munmap(_arena_start, header->size);
        _arena_start = NULL;
        header = NULL;
        statusno = ERR_UNINITIALIZED;
    }
    return 0;
}
extern void* walloc(size_t size){
    
}
extern void wfree(void *ptr){

}