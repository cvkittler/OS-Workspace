#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    int masterID = getpid();
    char buffer[255];
    int children[4];

    for(int i = 0; i < 4 && (getpid() == masterID); i++){
        int childID = fork();
        if(childID == 0 ){
            printf("    [Child, PID: %d]: Executing ’./slug %d’ command....\n",getpid(), i + 1);
            sprintf(buffer, "./slug %d", i + 1);
            system(buffer);
            exit(0);
        }else{
            printf("[Parent]: I forked off child %d.\n",childID);
            children[i] = childID;
        }
    }
    int flag = 1;
    int racers[4] = {children[0],children[1],children[2],children[3]};
    while(flag && (getpid() == masterID)){
        int status;
        int A, B, C, D;
        printf("The race is ongoing. The following children are still racing: ");
        waitpid(children[0], &status, WNOHANG);
        A = WEXITSTATUS(status);
        if (A != 0){
            printf(" %d ", children[0]);
        }
        waitpid(children[1], &status, WNOHANG);
        B = WEXITSTATUS(status);
        if (B != 0){
            printf(" %d ",children[1]);
        }
        waitpid(children[2], &status, WNOHANG);
        C = WEXITSTATUS(status);
        if (C != 0){
            printf(" %d ",children[2]);
        }
        waitpid(children[3], &status, WNOHANG);
        D = WEXITSTATUS(status);
        if (D != 0){
            printf(" %d ",children[3]);
        }
        printf("\n");
        if((A == 0) && (B == 0) && (C == 0) && (D == 0)){
            flag = 0;
        }
        usleep(250000);
    }
}