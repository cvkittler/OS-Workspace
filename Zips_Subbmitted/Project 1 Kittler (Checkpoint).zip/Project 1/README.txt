README

Author: Charles Kittler

prolific.c 
    prolific.c uses a for loop to generate childen

generation.c 
    generation.c uses recurstion to make the childen