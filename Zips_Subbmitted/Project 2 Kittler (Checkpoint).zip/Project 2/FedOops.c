#include <stdio.h>

/*
Tasks:
    Weighing:
    Barcoding:
    X-Raying:
    Jostling:

Stations (General):
    - Each station has 4 teams
    - each team can have one package at a time
    - once they are done they tag in the next teamate
    - each team has 10 workers
    - packages can't be put down
    - Workers move between stations with packages
    - One Package per station
    - no breaks for the packages between stations
    - target destination must be empty
    - only one move at a time (atomic)

Package:
    - One to Four Steps
    - a "Pile" will be delivered to each station
    - each package has a set of instructions
    - Customers now get to pick the steps that these things happen in

*/


int main(){
    int counter;
    int randomNumbers[15];
    //TODO: read the seed from seed.txt
    FILE *fp;
    char buffer[255];
    int seed;

    fp = fopen("./seed.txt", "r");
    fscanf(fp, "%s", buffer);
    seed = atoi(buffer);
    printf("Read seed value: %s\n\n", buffer);
    printf("Read seed value (converted to integer): %d\n", seed);

    srand(seed);
}

// referance "pthread_create(&t1,NULL,test,NULL);"
/*
    //make a semafor for the stage and entrance
    sem_init(&Stage, 0, STAGE_SIZE);
    sem_init(&stageEntrance,0,1);

    //Make all the proformers  
    //make the dancers
    pthread_t dancers[15];
    for(int i = 0; i < sizeof(dancer); i ++){
        pthread_create(&dancers[i], NULL, dancer, &i);
    }
    //make juggelers 
    pthread_t juggelers[8];
    for(int i = 0; i < sizeof(juggelers); i ++){
        pthread_create(&juggelers[i], NULL, juggeler, &i);
    }
    //make soloists 
    pthread_t Singer, Magician;
        pthread_create(&Singer, NULL, soloist, "Singer");
        pthread_create(&Magician, NULL, soloist, "Magician");
        */